-- Fix the employee_id column to be auto-generated
-- Drop the old column and create a new one with auto-increment
ALTER TABLE public.employees 
DROP COLUMN IF EXISTS employee_id CASCADE;

-- Add the employee_id column as SERIAL/auto-increment
-- First, we'll add it as nullable, then populate it, then make it NOT NULL
ALTER TABLE public.employees 
ADD COLUMN employee_id INT UNIQUE;

-- Create a sequence for employee_id starting from 1001
CREATE SEQUENCE IF NOT EXISTS employee_id_seq START 1001;

-- Populate existing records with auto-incremented IDs
UPDATE public.employees 
SET employee_id = nextval('employee_id_seq')
WHERE employee_id IS NULL;

-- Make the column NOT NULL and set the default
ALTER TABLE public.employees 
ALTER COLUMN employee_id SET NOT NULL,
ALTER COLUMN employee_id SET DEFAULT nextval('employee_id_seq');

-- Fix the attendance table to use INT for employee_id instead of text
ALTER TABLE public.attendance
ALTER COLUMN employee_id TYPE INT USING (employee_id::INT);

-- Add foreign key constraint from attendance to employees
ALTER TABLE public.attendance
ADD CONSTRAINT fk_attendance_employee 
FOREIGN KEY (employee_id) REFERENCES public.employees(employee_id) ON DELETE CASCADE;

'use client'

import { useEffect, useState } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Users, CheckCircle, XCircle, Loader2, TrendingUp } from 'lucide-react'
import { Alert, AlertDescription } from '@/components/ui/alert'

interface DashboardSummary {
  totalEmployees: number
  presentToday: number
  absentToday: number
  attendanceRate?: number
}

export function Dashboard() {
  const [summary, setSummary] = useState<DashboardSummary | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchSummary()
  }, [])

  const fetchSummary = async () => {
    try {
      setLoading(true)
      const response = await fetch('/api/attendance')
      if (!response.ok) throw new Error('Failed to fetch summary')
      const data = await response.json()
      
      // Handle both old format (direct properties) and new format (summary object)
      const summaryData = data.summary || data
      const total = summaryData.totalEmployees || 0
      const present = summaryData.presentToday || 0
      const rate = total > 0 ? Math.round((present / total) * 100) : 0
      
      const summary = {
        totalEmployees: total,
        presentToday: present,
        absentToday: summaryData.absentToday || 0,
        attendanceRate: rate,
      }
      setSummary(summary)
      setError(null)
    } catch (err: any) {
      setError(err.message || 'Failed to load dashboard')
      setSummary(null)
    } finally {
      setLoading(false)
    }
  }

  const statsCards = summary
    ? [
        {
          label: 'Total Employees',
          value: summary.totalEmployees,
          icon: <Users className="w-8 h-8 text-blue-500" />,
          bgColor: 'bg-blue-50',
        },
        {
          label: 'Present Today',
          value: summary.presentToday,
          icon: <CheckCircle className="w-8 h-8 text-green-500" />,
          bgColor: 'bg-green-50',
        },
        {
          label: 'Absent Today',
          value: summary.absentToday,
          icon: <XCircle className="w-8 h-8 text-red-500" />,
          bgColor: 'bg-red-50',
        },
        {
          label: 'Attendance Rate',
          value: `${summary.attendanceRate || 0}%`,
          icon: <TrendingUp className="w-8 h-8 text-blue-500" />,
          bgColor: 'bg-blue-50',
          subtext: "Today's attendance",
        },
      ]
    : []

  return (
    <div className="p-8 bg-white min-h-screen">
      <div className="mb-8">
        <h1 className="text-4xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-600 mt-2">Overview of employee attendance and metrics</p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {statsCards.map((card: any) => (
            <Card key={card.label} className="border-gray-200 bg-white hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="space-y-4">
                  <div className="flex items-center justify-between">
                    <p className="text-sm font-medium text-gray-600">{card.label}</p>
                    <div className={`p-2.5 rounded-lg ${card.bgColor}`}>{card.icon}</div>
                  </div>
                  <div className="space-y-1">
                    <div className="text-4xl font-bold text-gray-900">{card.value}</div>
                    {card.subtext && <p className="text-xs text-gray-500">{card.subtext}</p>}
                  </div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      )}

      <Card className="border-gray-200 bg-white">
        <CardHeader>
          <CardTitle className="text-gray-900">Department-wise Attendance</CardTitle>
          <CardDescription className="text-gray-600">Attendance overview by department</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="text-sm text-gray-500 text-center py-8">
              Start managing your employees and track attendance to see department-wise statistics here.
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

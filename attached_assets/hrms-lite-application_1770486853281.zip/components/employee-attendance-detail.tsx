'use client'

import { useState, useEffect } from 'react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Alert, AlertDescription } from '@/components/ui/alert'
import { Loader2, ArrowLeft } from 'lucide-react'

interface AttendanceRecord {
  id: number
  employee_id: string
  date: string
  status: 'Present' | 'Absent'
}

interface AttendanceSummary {
  presentCount: number
  absentCount: number
  totalDays: number
}

interface Props {
  employeeId: string
  employeeName: string
  onBack: () => void
}

export function EmployeeAttendanceDetail({ employeeId, employeeName, onBack }: Props) {
  const [attendance, setAttendance] = useState<AttendanceRecord[]>([])
  const [summary, setSummary] = useState<AttendanceSummary | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    fetchAttendanceData()
  }, [employeeId])

  const fetchAttendanceData = async () => {
    try {
      setLoading(true)
      // Fetch attendance records
      const recordsResponse = await fetch(`/api/attendance/${employeeId}`)
      if (!recordsResponse.ok) throw new Error('Failed to fetch attendance records')
      const recordsData = await recordsResponse.json()
      setAttendance(recordsData.data || [])

      // Fetch summary
      const summaryResponse = await fetch(`/api/attendance/${employeeId}?summary=true`)
      if (!summaryResponse.ok) throw new Error('Failed to fetch summary')
      const summaryData = await summaryResponse.json()
      setSummary(summaryData.data || null)

      setError(null)
    } catch (err: any) {
      setError(err.message || 'Failed to load attendance data')
    } finally {
      setLoading(false)
    }
  }

  const attendancePercentage =
    summary && summary.totalDays > 0
      ? Math.round((summary.presentCount / summary.totalDays) * 100)
      : 0

  return (
    <div className="p-8">
      <Button
        onClick={onBack}
        variant="ghost"
        className="mb-6 gap-2"
      >
        <ArrowLeft className="w-4 h-4" />
        Back
      </Button>

      <div className="mb-8">
        <h1 className="text-3xl font-bold text-foreground">{employeeName}</h1>
        <p className="text-muted-foreground mt-2">Employee ID: {employeeId}</p>
      </div>

      {error && (
        <Alert variant="destructive" className="mb-6">
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {loading ? (
        <div className="flex items-center justify-center py-12">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
        </div>
      ) : (
        <div className="space-y-6">
          {/* Summary Cards */}
          {summary && (
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <Card className="border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Total Days
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-foreground">{summary.totalDays}</div>
                </CardContent>
              </Card>

              <Card className="border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Present Days
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-green-600">{summary.presentCount}</div>
                </CardContent>
              </Card>

              <Card className="border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Absent Days
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-red-600">{summary.absentCount}</div>
                </CardContent>
              </Card>

              <Card className="border-border">
                <CardHeader className="pb-3">
                  <CardTitle className="text-sm font-medium text-muted-foreground">
                    Attendance %
                  </CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold text-blue-600">{attendancePercentage}%</div>
                </CardContent>
              </Card>
            </div>
          )}

          {/* Attendance Records Table */}
          <Card className="border-border">
            <CardHeader>
              <CardTitle>Attendance History</CardTitle>
              <CardDescription>
                {attendance.length} record{attendance.length !== 1 ? 's' : ''}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {attendance.length === 0 ? (
                <div className="text-center py-12">
                  <p className="text-muted-foreground">No attendance records found.</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-border">
                        <TableHead className="text-foreground">Date</TableHead>
                        <TableHead className="text-foreground">Status</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {attendance.map((record) => (
                        <TableRow key={record.id} className="border-border">
                          <TableCell className="text-foreground">{record.date}</TableCell>
                          <TableCell>
                            <span
                              className={`px-3 py-1 rounded-full text-sm font-medium ${
                                record.status === 'Present'
                                  ? 'bg-green-100 text-green-800'
                                  : 'bg-red-100 text-red-800'
                              }`}
                            >
                              {record.status}
                            </span>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      )}
    </div>
  )
}

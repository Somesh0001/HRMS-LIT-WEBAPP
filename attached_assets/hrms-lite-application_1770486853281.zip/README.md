# HRMS Lite - Human Resource Management System

A production-ready, full-stack HR management system built with Next.js for managing employees and tracking attendance with a clean, professional admin dashboard.

## 🎯 Project Overview

HRMS Lite is a comprehensive HR management solution designed to streamline employee management and attendance tracking. It provides a user-friendly interface for HR administrators to manage employee records, mark attendance, and generate analytics reports.

### Core Features
- **Employee Management**: Add, view, and delete employee records with unique IDs and validation
- **Attendance Tracking**: Mark and track employee attendance with date-based filtering
- **Dashboard Analytics**: Real-time summary cards showing total employees, present/absent counts
- **Per-Employee Reports**: View individual attendance history and attendance percentages
- **CSV Export**: Export attendance records for analysis and reporting

### Bonus Features Implemented
✅ Dashboard summary cards (Total Employees, Present Today, Absent Today)  
✅ Attendance filtering by date  
✅ CSV export for attendance records  
✅ Per-employee attendance summary with statistics and history  

## 🛠️ Tech Stack

### Frontend
- **Framework**: Next.js 16.1.6 with App Router
- **UI Library**: React 19 with shadcn/ui components
- **Styling**: Tailwind CSS 3.4.17
- **State Management**: React hooks with client-side state
- **Form Handling**: React Hook Form with Zod validation
- **Icons**: Lucide React

### Backend
- **Runtime**: Node.js with Next.js API Routes
- **Database**: SQLite with better-sqlite3
- **Validation**: Custom server-side validation with error handling
- **API Design**: RESTful API with proper HTTP status codes

### Database
- **Type**: SQLite (embedded, zero-configuration)
- **Schema**: Employees and Attendance tables with relationships
- **Features**: Foreign keys, indexes, constraints, cascade deletion

## 📁 Project Structure

```
hrms-lite/
├── app/
│   ├── layout.tsx              # Root layout with metadata
│   ├── page.tsx                # Main dashboard page
│   ├── globals.css             # Global Tailwind styles
│   └── api/
│       ├── employees/          # Employee API routes
│       │   ├── route.ts        # GET (list) & POST (create)
│       │   └── [employeeId]/route.ts  # GET & DELETE (detail)
│       └── attendance/         # Attendance API routes
│           ├── route.ts        # GET & POST (with CSV export)
│           └── [employeeId]/route.ts  # GET (by employee, with summary)
├── components/
│   ├── sidebar.tsx             # Navigation sidebar
│   ├── dashboard.tsx           # Dashboard with summary cards
│   ├── employee-list.tsx       # Employee management interface
│   ├── attendance-tracker.tsx  # Attendance marking interface
│   ├── employee-attendance-detail.tsx  # Individual attendance view
│   └── ui/                     # shadcn/ui components
├── lib/
│   ├── db.ts                   # SQLite database initialization
│   ├── db-operations.ts        # Database operation functions
│   └── utils.ts                # Utility functions
├── public/                     # Static assets
├── package.json                # Dependencies and scripts
├── tsconfig.json               # TypeScript configuration
└── README.md                   # This file
```

## 🚀 Getting Started

### Prerequisites
- Node.js 18+ or compatible runtime
- npm or yarn package manager

### Installation & Setup

1. **Install dependencies:**
   ```bash
   npm install
   ```

2. **Configure environment (optional):**
   ```bash
   # Create a .env.local file (optional)
   DB_DIR=./data  # Custom database directory
   ```

3. **Run development server:**
   ```bash
   npm run dev
   ```

4. **Open application:**
   - Navigate to `http://localhost:3000` in your browser
   - The SQLite database will be automatically created on first run

### Production Build

```bash
npm run build
npm start
```

## 📊 API Endpoints

### Employee Management

#### GET `/api/employees`
- **Description**: Retrieve all employees
- **Response**: `{ data: Employee[] }`
- **Status**: 200 OK

#### POST `/api/employees`
- **Description**: Create a new employee
- **Body**:
  ```json
  {
    "employee_id": "EMP001",
    "full_name": "John Doe",
    "email": "john@example.com",
    "department": "Engineering"
  }
  ```
- **Response**: `{ message: string, data: { id: number } }`
- **Status**: 201 Created / 400 Bad Request / 409 Conflict (duplicate ID)

#### GET `/api/employees/[employeeId]`
- **Description**: Get employee details
- **Response**: `{ data: Employee }`
- **Status**: 200 OK / 404 Not Found

#### DELETE `/api/employees/[employeeId]`
- **Description**: Delete an employee
- **Response**: `{ message: string }`
- **Status**: 200 OK / 404 Not Found

### Attendance Management

#### GET `/api/attendance`
- **Description**: Get attendance summary or export records
- **Query Parameters**:
  - `export=true`: Export as CSV file
  - `date=YYYY-MM-DD`: Filter by specific date
  - `startDate` & `endDate`: Date range for export
- **Response**: `{ data: { totalEmployees, presentToday, absentToday } }`
- **Status**: 200 OK

#### POST `/api/attendance`
- **Description**: Mark attendance for an employee
- **Body**:
  ```json
  {
    "employee_id": "EMP001",
    "date": "2024-01-15",
    "status": "Present"
  }
  ```
- **Response**: `{ message: string, data: { id: number } }`
- **Status**: 201 Created / 400 Bad Request / 404 Not Found / 409 Conflict

#### GET `/api/attendance/[employeeId]`
- **Description**: Get attendance records for an employee
- **Query Parameters**:
  - `summary=true`: Get attendance statistics instead of records
- **Response**:
  - Records: `{ data: AttendanceRecord[] }`
  - Summary: `{ data: { presentCount, absentCount, totalDays } }`
- **Status**: 200 OK

## 📋 Database Schema

### Employees Table
```sql
CREATE TABLE employees (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  employee_id TEXT UNIQUE NOT NULL,
  full_name TEXT NOT NULL,
  email TEXT NOT NULL,
  department TEXT NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP
)
```

### Attendance Table
```sql
CREATE TABLE attendance (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  employee_id TEXT NOT NULL,
  date DATE NOT NULL,
  status TEXT NOT NULL CHECK (status IN ('Present', 'Absent')),
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (employee_id) REFERENCES employees(employee_id) ON DELETE CASCADE,
  UNIQUE(employee_id, date)
)
```

## ✅ Validation & Error Handling

### Employee Validation
- Employee ID: Required, must be unique
- Full Name: Required, non-empty string
- Email: Required, valid email format
- Department: Required, non-empty string

### Attendance Validation
- Employee ID: Required, must exist in employees table
- Date: Required, valid date format
- Status: Must be "Present" or "Absent"
- Duplicate Prevention: Cannot mark same employee twice on same date

### Error Messages
- Clear, descriptive error messages for validation failures
- Proper HTTP status codes (400, 404, 409, 500)
- JSON response format with error details

## 🎨 UI/UX Features

- **Professional Dashboard**: Modern admin interface with navigation sidebar
- **Responsive Design**: Works seamlessly on desktop, tablet, and mobile
- **Loading States**: Spinner indicators during API calls
- **Error Handling**: Graceful error alerts for failed operations
- **Success Feedback**: Confirmation messages for successful operations
- **Empty States**: Helpful messages when no data is available
- **Confirmation Dialogs**: Safety prompts before destructive actions
- **Data Tables**: Clean, sortable presentation of records

## 🔄 User Workflows

### Adding an Employee
1. Navigate to "Employees" page
2. Fill in employee details in the form
3. Click "Add Employee"
4. See success confirmation and updated list

### Marking Attendance
1. Navigate to "Attendance" page
2. Select employee from dropdown
3. Choose date and status
4. Click "Mark Attendance"
5. View updated attendance records below

### Viewing Employee Attendance
1. Navigate to "Employees" page
2. Click the eye icon on any employee row
3. View attendance statistics and history
4. Click "Back" to return to employee list

### Exporting Attendance
1. Navigate to "Attendance" page
2. Click "Export CSV" button
3. CSV file downloads automatically with all attendance records

## 🚢 Deployment

### Prerequisites for Deployment
- Remove any `.env.local` file with sensitive data
- Ensure `data/` directory exists or is created automatically
- Node.js compatible hosting environment

### Deploy to Vercel

1. **Connect your repository:**
   - Push code to GitHub, GitLab, or Bitbucket
   - Connect repository to Vercel dashboard

2. **Configure environment:**
   - Set environment variables in Vercel dashboard (if needed)

3. **Deploy:**
   - Automatic deployment on push
   - Vercel CLI: `vercel deploy`

### Deploy Backend (if using external hosting)

The backend APIs run within Next.js, so no separate backend deployment needed. All logic is contained in the Next.js application.

### Database Persistence

- Development: SQLite database stored in `./data/` directory
- Production: Ensure persistent storage for `data/` directory
  - Vercel: Use Vercel KV or external database
  - Self-hosted: Mount persistent volume
  - Alternative: Migrate to Neon PostgreSQL or similar

## 📝 Configuration

### Environment Variables

```env
# Optional: Custom database directory
DB_DIR=./data

# Optional: Next.js configuration
NODE_ENV=production
```

### Next.js Configuration

No special configuration required. Default `next.config.mjs` works out of the box.

## 🔒 Security Considerations

### Implemented
- Server-side validation for all inputs
- SQL injection prevention with parameterized queries
- Unique constraints on employee IDs
- Email format validation
- Proper error handling without exposing system details

### Recommendations for Production
- Add authentication/authorization layer
- Implement rate limiting on API endpoints
- Use HTTPS for all communications
- Add audit logging for sensitive operations
- Implement role-based access control (RBAC)
- Use environment variables for all config
- Regular database backups

## ⚠️ Known Limitations & Assumptions

- **Single Admin User**: No authentication system (assumes single admin access)
- **No User Roles**: All users have full access
- **SQLite Only**: Database choice limited to SQLite in development
- **No Real-time Sync**: Changes require page refresh
- **No Bulk Operations**: Operations one record at a time
- **No Advanced Reporting**: Basic CSV export only
- **No Leave Management**: Out of scope per requirements
- **No Payroll**: Out of scope per requirements

## 🐛 Troubleshooting

### Database Connection Issues
- Ensure `data/` directory has write permissions
- Check NODE_ENV is not preventing database creation

### API Errors
- Check browser console for detailed error messages
- Verify all required fields are provided
- Ensure employee IDs are unique

### Styling Issues
- Clear browser cache
- Run `npm install` to ensure all dependencies installed
- Check Tailwind CSS is properly configured

## 📞 Support

For issues or questions:
1. Check the API endpoints documentation above
2. Review component files for implementation details
3. Check database schema and constraints
4. Review server-side validation in `lib/db-operations.ts`

## 📄 License

This project is provided as-is for evaluation purposes.

## 🎓 Learning Resources

- [Next.js Documentation](https://nextjs.org/docs)
- [React Documentation](https://react.dev)
- [shadcn/ui Components](https://ui.shadcn.com)
- [Tailwind CSS](https://tailwindcss.com)
- [SQLite](https://www.sqlite.org)

---

**Last Updated**: January 2025  
**Version**: 1.0.0

# HRMS Lite - Deployment Guide

This guide covers deploying HRMS Lite to various platforms.

## 🚀 Deploy to Vercel (Recommended)

### Option 1: Using Vercel Dashboard

1. **Prepare your code:**
   ```bash
   git init
   git add .
   git commit -m "Initial commit"
   git branch -M main
   ```

2. **Push to GitHub:**
   ```bash
   git remote add origin https://github.com/username/hrms-lite.git
   git push -u origin main
   ```

3. **Connect to Vercel:**
   - Go to [vercel.com](https://vercel.com)
   - Click "New Project"
   - Select your GitHub repository
   - Click "Import"

4. **Configure:**
   - Framework: Next.js (auto-detected)
   - Root Directory: ./
   - Build Command: `npm run build`
   - Output Directory: `.next`
   - Environment: Leave default

5. **Deploy:**
   - Click "Deploy"
   - Wait for deployment to complete
   - Your app is now live!

### Option 2: Using Vercel CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Login to Vercel
vercel login

# Deploy
vercel

# For production
vercel --prod
```

### Database Persistence on Vercel

**Important:** By default, SQLite files in `/data` will be lost on redeployment.

#### Option A: Use Vercel KV (Redis)
1. Add Vercel KV integration
2. Replace SQLite with Vercel KV for production

#### Option B: Use Neon PostgreSQL
1. Create a Neon account at [neon.tech](https://neon.tech)
2. Create a new project and get connection string
3. Install postgres driver: `npm install pg`
4. Update database layer to use PostgreSQL

#### Option C: Use Supabase
1. Create a Supabase project
2. Get connection string
3. Update database layer accordingly

#### Option D: Use Render PostgreSQL
1. Create account at [render.com](https://render.com)
2. Create PostgreSQL database
3. Get connection string
4. Set as environment variable

## 📦 Deploy to Render

Render supports full-stack Next.js deployment with persistent storage.

1. **Create Render account:**
   - Go to [render.com](https://render.com)
   - Sign up with GitHub

2. **Create Web Service:**
   - Click "New +"
   - Select "Web Service"
   - Connect GitHub repository
   - Select branch (main)

3. **Configure:**
   - Name: `hrms-lite`
   - Environment: `Node`
   - Region: Choose closest to users
   - Branch: `main`
   - Build Command: `npm install && npm run build`
   - Start Command: `npm start`

4. **Advanced Settings:**
   - Add environment variables if needed
   - Set disk mount: `/data` → persistent

5. **Deploy:**
   - Click "Create Web Service"
   - Wait for deployment

## 🏠 Self-Hosted Deployment

### Requirements
- Node.js 18+ installed
- npm or yarn
- Linux/Windows/macOS server
- Domain name (optional)
- SSL certificate (for HTTPS)

### Step-by-Step

1. **Clone repository:**
   ```bash
   git clone https://github.com/username/hrms-lite.git
   cd hrms-lite
   ```

2. **Install dependencies:**
   ```bash
   npm install
   ```

3. **Build application:**
   ```bash
   npm run build
   ```

4. **Create systemd service (Linux):**
   ```bash
   sudo nano /etc/systemd/system/hrms-lite.service
   ```

   Add:
   ```ini
   [Unit]
   Description=HRMS Lite Application
   After=network.target

   [Service]
   Type=simple
   User=nodeuser
   WorkingDirectory=/home/nodeuser/hrms-lite
   ExecStart=/usr/bin/node /home/nodeuser/hrms-lite/node_modules/.bin/next start
   Restart=on-failure
   RestartSec=10
   Environment="NODE_ENV=production"
   StandardOutput=syslog
   StandardError=syslog
   SyslogIdentifier=hrms-lite

   [Install]
   WantedBy=multi-user.target
   ```

   Then:
   ```bash
   sudo systemctl daemon-reload
   sudo systemctl enable hrms-lite
   sudo systemctl start hrms-lite
   sudo systemctl status hrms-lite
   ```

5. **Setup Nginx reverse proxy:**
   ```bash
   sudo apt-get install nginx
   sudo nano /etc/nginx/sites-available/hrms-lite
   ```

   Add:
   ```nginx
   server {
       listen 80;
       server_name yourdomain.com;

       location / {
           proxy_pass http://localhost:3000;
           proxy_http_version 1.1;
           proxy_set_header Upgrade $http_upgrade;
           proxy_set_header Connection 'upgrade';
           proxy_set_header Host $host;
           proxy_cache_bypass $http_upgrade;
       }
   }
   ```

   Then:
   ```bash
   sudo ln -s /etc/nginx/sites-available/hrms-lite /etc/nginx/sites-enabled/
   sudo nginx -t
   sudo systemctl restart nginx
   ```

6. **Setup SSL with Certbot:**
   ```bash
   sudo apt-get install certbot python3-certbot-nginx
   sudo certbot --nginx -d yourdomain.com
   ```

## 📊 Monitoring & Maintenance

### Check Application Status
```bash
# Vercel
vercel status

# Render
# Check via dashboard

# Self-hosted (systemd)
sudo systemctl status hrms-lite
sudo journalctl -u hrms-lite -f
```

### View Logs

**Vercel:**
- Open project dashboard → Deployments → Logs

**Render:**
- Open service → Logs

**Self-hosted:**
```bash
sudo journalctl -u hrms-lite -f
tail -f /var/log/syslog | grep hrms-lite
```

### Database Backups

```bash
# SQLite backup
cp data/hrms.db data/hrms.db.backup

# Or automated backup (cron)
0 2 * * * cp /home/nodeuser/hrms-lite/data/hrms.db /backups/hrms.db.$(date +\%Y\%m\%d)
```

## 🔐 Production Checklist

- [ ] Environment variables configured
- [ ] Database backed up
- [ ] HTTPS enabled
- [ ] Error logging configured
- [ ] Database connection tested
- [ ] Performance monitoring set up
- [ ] Rate limiting configured
- [ ] Authentication added (if required)
- [ ] CORS properly configured
- [ ] Sensitive data removed from code

## 🆘 Troubleshooting Deployment

### Port Already in Use
```bash
# Find process on port 3000
lsof -i :3000
# Kill it
kill -9 <PID>
```

### Database Connection Failed
- Check database directory exists: `mkdir -p data`
- Check write permissions: `chmod 755 data`
- Verify database path in environment

### Application Won't Start
```bash
# Run locally first
npm run dev

# Check build
npm run build

# Check dependencies
npm list

# Clear cache
rm -rf .next node_modules
npm install
npm run build
```

### Memory Issues
- Increase Node.js heap: `NODE_OPTIONS="--max-old-space-size=2048" npm start`
- Monitor with: `node --inspect app.js`

## 📞 Support

For deployment issues:
1. Check Vercel/Render documentation
2. Review application logs
3. Test locally with `npm run dev`
4. Check environment variables
5. Verify database connectivity

---

**Last Updated**: January 2025

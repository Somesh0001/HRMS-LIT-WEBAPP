import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ employeeId: string }> }
) {
  try {
    const { employeeId } = await params
    const { searchParams } = new URL(request.url)
    const summary = searchParams.get('summary')

    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            try {
              cookiesToSet.forEach(({ name, value, options }) =>
                cookieStore.set(name, value, options),
              )
            } catch {
              // The `setAll` method was called from a Server Component.
            }
          },
        },
      },
    )

    if (summary === 'true') {
      const { data: attendance } = await supabase
        .from('attendance')
        .select('*')
        .eq('employee_id', employeeId)

      const records = attendance || []
      const totalDays = records.length
      const presentDays = records.filter((a) => a.status === 'Present').length
      const absentDays = records.filter((a) => a.status === 'Absent').length
      const attendanceRate = totalDays > 0 ? Math.round((presentDays / totalDays) * 100) : 0

      return Response.json({
        totalDays,
        presentDays,
        absentDays,
        attendanceRate,
      })
    }

    const { data, error } = await supabase
      .from('attendance')
      .select('*')
      .eq('employee_id', employeeId)
      .order('date', { ascending: false })

    if (error) throw error

    return Response.json(data || [])
  } catch (error: any) {
    console.error('[v0] GET /api/attendance/:id error:', error.message)
    return Response.json(
      { error: error.message || 'Failed to fetch attendance' },
      { status: 500 },
    )
  }
}

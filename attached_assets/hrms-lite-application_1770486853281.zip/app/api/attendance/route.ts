import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)
    const exportCsv = searchParams.get('export')

    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            try {
              cookiesToSet.forEach(({ name, value, options }) =>
                cookieStore.set(name, value, options),
              )
            } catch {
              // The `setAll` method was called from a Server Component.
            }
          },
        },
      },
    )

    // CSV export endpoint
    if (exportCsv === 'true') {
      const { data: records, error } = await supabase
        .from('attendance')
        .select('employee_id, employees(full_name, email, department), date, status')
        .order('date', { ascending: false })

      if (error || !records) {
        return Response.json({ error: 'No records found' }, { status: 404 })
      }

      const headers = ['Employee ID', 'Full Name', 'Email', 'Department', 'Date', 'Status']
      const csvContent = [
        headers.join(','),
        ...(records as any[]).map((record) => {
          const emp = record.employees
          return [
            `"${record.employee_id}"`,
            `"${emp?.full_name || ''}"`,
            `"${emp?.email || ''}"`,
            `"${emp?.department || ''}"`,
            record.date,
            record.status,
          ].join(',')
        }),
      ].join('\n')

      return new Response(csvContent, {
        status: 200,
        headers: {
          'Content-Type': 'text/csv',
          'Content-Disposition': 'attachment; filename="attendance.csv"',
        },
      })
    }

    // Get attendance records with employee details
    const { data: records, error: recordsError } = await supabase
      .from('attendance')
      .select('id, employee_id, date, status, employees(full_name, email, department)')
      .order('date', { ascending: false })

    if (recordsError) throw recordsError

    // Also get dashboard summary
    const { data: employees } = await supabase
      .from('employees')
      .select('id')

    const { data: todayAttendance } = await supabase
      .from('attendance')
      .select('*')
      .eq('date', new Date().toISOString().split('T')[0])

    const totalEmployees = employees?.length || 0
    const presentToday = todayAttendance?.filter((a) => a.status === 'Present').length || 0
    const absentToday = todayAttendance?.filter((a) => a.status === 'Absent').length || 0

    // Return attendance records formatted for the table
    const formattedRecords = (records || []).map((record: any) => ({
      id: record.id,
      employee_id: record.employee_id,
      full_name: record.employees?.full_name || '',
      date: record.date,
      status: record.status,
    }))

    return Response.json({
      records: formattedRecords,
      summary: {
        totalEmployees,
        presentToday,
        absentToday,
      },
    })
  } catch (error: any) {
    console.error('[v0] GET /api/attendance error:', error.message)
    return Response.json(
      { error: error.message || 'Failed to fetch attendance' },
      { status: 500 },
    )
  }
}

export async function POST(request: Request) {
  try {
    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            try {
              cookiesToSet.forEach(({ name, value, options }) =>
                cookieStore.set(name, value, options),
              )
            } catch {
              // The `setAll` method was called from a Server Component.
            }
          },
        },
      },
    )

    const body = await request.json()
    const { employee_id, date, status } = body

    // Validate required fields
    if (!employee_id || !date || !status) {
      return Response.json(
        { error: 'Missing required fields' },
        { status: 400 },
      )
    }

    // Check if employee exists
    const { data: employee } = await supabase
      .from('employees')
      .select('id')
      .eq('id', employee_id)
      .single()

    if (!employee) {
      return Response.json(
        { error: 'Employee not found' },
        { status: 404 },
      )
    }

    // Check if attendance already marked
    const { data: existing } = await supabase
      .from('attendance')
      .select('id')
      .eq('employee_id', employee_id)
      .eq('date', date)
      .single()

    if (existing) {
      return Response.json(
        { error: 'Attendance already marked for this employee on this date' },
        { status: 409 },
      )
    }

    const { data, error } = await supabase
      .from('attendance')
      .insert([{ employee_id, date, status }])
      .select()
      .single()

    if (error) throw error

    return Response.json(data, { status: 201 })
  } catch (error: any) {
    console.error('[v0] POST /api/attendance error:', error.message)
    return Response.json(
      { error: error.message || 'Failed to mark attendance' },
      { status: 500 },
    )
  }
}

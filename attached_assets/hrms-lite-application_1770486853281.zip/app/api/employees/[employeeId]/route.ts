import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'

export async function GET(
  request: Request,
  { params }: { params: Promise<{ employeeId: string }> }
) {
  try {
    const { employeeId } = await params
    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            try {
              cookiesToSet.forEach(({ name, value, options }) =>
                cookieStore.set(name, value, options),
              )
            } catch {
              // The `setAll` method was called from a Server Component.
            }
          },
        },
      },
    )

    const { data, error } = await supabase
      .from('employees')
      .select('*')
      .eq('id', employeeId)
      .single()

    if (error || !data) {
      return Response.json({ error: 'Employee not found' }, { status: 404 })
    }

    return Response.json(data)
  } catch (error: any) {
    console.error('[v0] GET /api/employees/:id error:', error.message)
    return Response.json(
      { error: error.message || 'Failed to fetch employee' },
      { status: 500 },
    )
  }
}

export async function DELETE(
  request: Request,
  { params }: { params: Promise<{ employeeId: string }> }
) {
  try {
    const { employeeId } = await params
    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            try {
              cookiesToSet.forEach(({ name, value, options }) =>
                cookieStore.set(name, value, options),
              )
            } catch {
              // The `setAll` method was called from a Server Component.
            }
          },
        },
      },
    )

    const { error } = await supabase
      .from('employees')
      .delete()
      .eq('id', employeeId)

    if (error) throw error

    return Response.json({ message: 'Employee deleted successfully' })
  } catch (error: any) {
    console.error('[v0] DELETE /api/employees/:id error:', error.message)
    return Response.json(
      { error: error.message || 'Failed to delete employee' },
      { status: 500 },
    )
  }
}

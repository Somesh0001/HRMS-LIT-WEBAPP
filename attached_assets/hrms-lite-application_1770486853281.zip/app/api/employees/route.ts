import { createServerClient } from '@supabase/ssr'
import { cookies } from 'next/headers'

export async function GET() {
  try {
    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            try {
              cookiesToSet.forEach(({ name, value, options }) =>
                cookieStore.set(name, value, options),
              )
            } catch {
              // The `setAll` method was called from a Server Component.
            }
          },
        },
      },
    )

    const { data, error } = await supabase
      .from('employees')
      .select('*')
      .order('created_at', { ascending: false })

    if (error) throw error

    return Response.json(data || [])
  } catch (error: any) {
    console.error('[v0] GET /api/employees error:', error.message)
    return Response.json(
      { error: error.message || 'Failed to fetch employees' },
      { status: 500 },
    )
  }
}

export async function POST(request: Request) {
  try {
    const cookieStore = await cookies()
    const supabase = createServerClient(
      process.env.NEXT_PUBLIC_SUPABASE_URL!,
      process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
      {
        cookies: {
          getAll() {
            return cookieStore.getAll()
          },
          setAll(cookiesToSet) {
            try {
              cookiesToSet.forEach(({ name, value, options }) =>
                cookieStore.set(name, value, options),
              )
            } catch {
              // The `setAll` method was called from a Server Component.
            }
          },
        },
      },
    )

    const body = await request.json()

    // Validate required fields
    if (!body.full_name || !body.email || !body.position || !body.department) {
      return Response.json(
        { error: 'Missing required fields' },
        { status: 400 },
      )
    }

    // Check if email already exists
    const { data: existing } = await supabase
      .from('employees')
      .select('id')
      .eq('email', body.email)
      .single()

    if (existing) {
      return Response.json(
        { error: 'Email already exists' },
        { status: 400 },
      )
    }

    const { data, error } = await supabase
      .from('employees')
      .insert([
        {
          full_name: body.full_name,
          email: body.email,
          position: body.position,
          department: body.department,
        },
      ])
      .select()
      .single()

    if (error) throw error

    return Response.json(data, { status: 201 })
  } catch (error: any) {
    console.error('[v0] POST /api/employees error:', error.message)
    return Response.json(
      { error: error.message || 'Failed to create employee' },
      { status: 500 },
    )
  }
}

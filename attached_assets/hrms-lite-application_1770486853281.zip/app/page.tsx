'use client'

import { useState } from 'react'
import { Sidebar } from '@/components/sidebar'
import { Dashboard } from '@/components/dashboard'
import { EmployeeList } from '@/components/employee-list'
import { AttendanceTracker } from '@/components/attendance-tracker'

type Page = 'dashboard' | 'employees' | 'attendance'

export default function Home() {
  const [currentPage, setCurrentPage] = useState<Page>('dashboard')

  return (
    <div className="flex h-screen bg-gray-50">
      <Sidebar currentPage={currentPage} onPageChange={setCurrentPage} />
      <main className="flex-1 overflow-auto bg-gray-50">
        {currentPage === 'dashboard' && <Dashboard />}
        {currentPage === 'employees' && <EmployeeList />}
        {currentPage === 'attendance' && <AttendanceTracker />}
      </main>
    </div>
  )
}
